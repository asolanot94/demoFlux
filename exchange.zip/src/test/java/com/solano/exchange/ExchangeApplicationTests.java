package com.solano.exchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
class ExchangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
